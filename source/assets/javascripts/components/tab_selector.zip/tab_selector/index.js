import React from 'react';
import { render } from "react-dom";

import Tabs from './Tabs';

import './styles.scss';


function App() {
  return (
    <div>
     <Tabs>
       <div label="hola">
       </div>
       <div label="hola2">
       </div>
       <div label="hola3">
       </div>
     </Tabs>
    </div>
  );
}

render(<App />,  document.getElementById('root'));
